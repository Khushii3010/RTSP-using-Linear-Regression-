import cv2
import numpy as np
import os

def capture_frames(sequence_number, frame_data, output_directory):
    # Convert frame_data to a NumPy array
    nparr = np.frombuffer(frame_data, np.uint8)

    # Decode the image
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # Check if the image is empty
    if frame is None or frame.size == 0:
        print("Error: Empty image or decoding failed.")
        return

    # Create the output directory if it doesn't exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # Save the frame with the sequence number in the filename
    frame_filename = f"frame_{sequence_number}.jpg"
    frame_path = os.path.join(output_directory, frame_filename)

    # Check if the image is successfully written
    success = cv2.imwrite(frame_path, frame)
    if not success:
        print("Error: Failed to write the image.")

    # Optionally, print the sequence number for verification
    print("Saved Frame with Sequence Number:", sequence_number)

# Example usage
sequence_number = 1
frame_data = b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00'
output_directory = 'path/to/your/dataset'

# Call the function with your actual sequence number and frame data
capture_frames(sequence_number, frame_data, output_directory)
