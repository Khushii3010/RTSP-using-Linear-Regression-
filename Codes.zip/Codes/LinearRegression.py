import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



def train_random_forest_model(dataset_path):
   # LINEAR REGRESSION PROJECT 01 : SIMPLE LINEAR REGRESSION

    # IMPORT ALL THE NECESSARY LIBRARIES
   
    # READING THE CSV FILE
    data = pd.read_csv(r"./dataset2.csv")


    # PREPARING DATA FOR PREDICTION
    data = data["_time;ip-10-10-20-161;current;Seq no;Latency"].values
    latencyposition = []
    for i in data:
        j = len(i) - i[::-1].index(";")
        latencyposition.append(j)
    
    latencydata = []
    for i in range(0, len(data)):
        lp = latencyposition[i]
        dp = data[i]
        lcurdata = eval(dp[lp:])
        ldata = 0
        for j in lcurdata:
            ldata += j[2]
        latencydata.append(ldata)

    X = [i for i in range(len(latencydata))]
    Y = latencydata


    # DETERMINING THE LENGTH & MEAN OF THE DATA
    x_mean = np.mean(X)
    y_mean = np.mean(Y)


    # COMPUTING THE COEFFICENTS -> SLOPE & INTERCEPT
    numerator = 0
    denominator = 0

    for i in range(len(latencydata)):
        numerator += ((X[i] - x_mean) * (Y[i] - y_mean))
        denominator += (X[i] - x_mean) ** 2
        
    slope = numerator / denominator
    intercept = (y_mean - (slope * x_mean))

    print('SLOPE : ' + str(slope) + '\nINTERCEPT : ' + str(intercept))

    x_max = np.max(X)
    x_min = np.min(X)
    x_plot = np.array([i for i in range(len(latencydata))])
    y_plot = (slope * x_plot) + intercept

    def perp_dist(x, y):
        return ((abs(slope*x - y + intercept))/(pow((slope**2 + 1), 0.5)))
    
    perp_dist_data = []
    for i in range(len(latencydata)):
        perp_dist_data.append(perp_dist(X[i], Y[i]))
        
    print(perp_dist_data[:5])

    plt.xlabel('NUMBER OF PACKETS')
    plt.ylabel('Latency')
    plt.legend()
    plt.plot(x_plot, y_plot, color = '#F4A950', label = 'Regression Line')
    plt.scatter(X, Y, color = '#161B21', label = 'Scatter Plot')
    plt.show()


    # EVALUATION BY ROOT MEAN SQUARE ERROR METHOD (RMSE)
    rmse = 0
    for i in range(len(latencydata)):
        y_predicted = slope * X[i] + intercept
        rmse += (Y[i] - y_predicted) ** 2
        
    rmse = np.sqrt(rmse/len(latencydata))
    print('RMSE : ' + str(rmse))


if __name__ == "__main__":
    # Provide the path to your dataset file
    dataset_path = 'dataset.csv'
    
    # Call the function to train and evaluate the Random Forest model
    train_random_forest_model(dataset_path)
