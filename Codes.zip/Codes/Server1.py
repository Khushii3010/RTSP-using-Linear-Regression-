import sys
import socket
from ServerWorker import ServerWorker

class Server:
    def __init__(self, server_port):
        self.SERVER_PORT = server_port

    def main(self):
        rtspSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        rtspSocket.bind(('', self.SERVER_PORT))
        rtspSocket.listen(5)

        # Receive client info (address,port) through RTSP/TCP session
        while True:
            clientInfo = {}
            clientInfo['rtspSocket'] = rtspSocket.accept()
            ServerWorker(clientInfo).run()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: Server.py <Server_port>")
        sys.exit(1)

    server_port = int(sys.argv[1])
    server = Server(server_port)
    server.main()
